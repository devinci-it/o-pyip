import argparse
import os
from tabulate import tabulate
from colorama import Fore, Style
from src.NetworkInterfaceManager import NetworkInterfaceManager

def banner():
    try:
        # Open the file in read mode
        with open("banner.txt", "r") as file:
            # Read the contents of the file
            banner_text = file.read()
            # Split the banner text into two parts
            split_index = len(banner_text) // 2
            first_part = banner_text[:split_index]
            second_part = banner_text[split_index:]
            # Colorize banner text
            colored_banner = f"{Fore.GREEN}{first_part}{Fore.BLUE}{second_part}{Style.RESET_ALL}"
            return colored_banner
    except FileNotFoundError:
        return "Error: The file 'banner.txt' was not found."

def main():
    os.system('clear')

    # Print the banner
    print(banner())

    # Check if running with sudo
    if os.geteuid() != 0:
        # Print colored banner
        print(banner())
        print(f"{Fore.RED}-:{'-' * 80}:-{Style.RESET_ALL}")

        # Print the warning message in red
        print(Fore.RED + "This script requires elevated privileges to access network interfaces.")
        print("Please run with 'sudo'." + Style.RESET_ALL)

        # Print the bottom separator
        print(f"{Fore.RED}-:{'-' * 80}:-{Style.RESET_ALL}")

        return

    # Define command-line arguments
    parser = argparse.ArgumentParser(description="Manage network interfaces")
    parser.add_argument("--interface", help="Name of the interface")
    parser.add_argument("--ip", help="IP address to set")
    parser.add_argument("--netmask", help="Netmask to set")
    parser.add_argument("--list", action="store_true", help="List available network interfaces\n")

    # Parse command-line arguments
    args = parser.parse_args()

    # Initialize NetworkInterfaceManager
    interface_manager = NetworkInterfaceManager()

    # Perform actions based on command-line arguments
    if args.list:
        # List available network interfaces
        interface_data = interface_manager.retrieve_interface_data()
        # Colorize and print the table
        colored_table = tabulate(interface_data, headers=["Interface", "IP Address", "Netmask", "DNS Servers", "Default Gateway"])
        print(f"{Fore.GREEN}{colored_table}{Style.RESET_ALL}")
    elif args.interface and args.ip and args.netmask:
        # Set IP address for the specified interface
        interface_manager.set_ip_address(args.interface, args.ip, args.netmask)
    else:
        # Print help message
        parser.print_help()

if __name__ == "__main__":
    main()
