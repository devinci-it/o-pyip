import logging
import netifaces

class NetworkInterfaceManager:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.INFO)
        self.interface_data = None
        self.log_messages = []
        self.interfaces = netifaces.interfaces()

    def set_ip_address(self, interface_name, ip_address, netmask):
        log_message = f"Interface {interface_name} configured with IP: {ip_address} and Netmask: {netmask}"
        self.log_messages.append(log_message)
        self.logger.info(log_message)


    def retrieve_interface_data(self):
        self.__list_interfaces()
        if (self.interface_data):
            self.logger.info('Data retrieved from private method')
            return self.interface_data
        else:
            self.logger.error('Exception occured')

    def __list_interfaces(self):
        try:
            self.interface_data = []  # Clear existing data
            gateways = netifaces.gateways()
            default_gateway = gateways.get('default', [])
            if default_gateway:
                default_gateway = default_gateway[netifaces.AF_INET][0][0]
            else:
                default_gateway = "None"

            for interface_name in netifaces.interfaces():
                if netifaces.AF_INET in netifaces.ifaddresses(interface_name):
                    ip_address = netifaces.ifaddresses(interface_name)[netifaces.AF_INET][0]['addr']
                    netmask = netifaces.ifaddresses(interface_name)[netifaces.AF_INET][0]['netmask']

                    # Retrieve DNS servers (IPv4 addresses)
                    dns_servers = ", ".join(
                        [dns_data['addr'] for dns_data in
                         netifaces.ifaddresses(interface_name).get(netifaces.AF_INET, [])]
                    )

                    self.interface_data.append([interface_name, ip_address, netmask, dns_servers, default_gateway])

            if not self.interface_data:
                raise RuntimeError("No network interfaces available")

            return self.interface_data
        except PermissionError:
            raise RuntimeError("Permission denied: Unable to access network interfaces. Try running with sudo.")
        except RuntimeError as e:
            raise e